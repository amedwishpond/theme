<div class="add-section ptb-60">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12 text-center">
                <div class="add-thumb">
                    @php 
                        echo advertisements("728x90")
                    @endphp
                </div>
            </div>
        </div>
    </div>
</div>