<aside class="aside-bar left-aside">
    <div class="aside-inner">
        <div class="add-item slot-1 mb-30">
            <div class="add-header text-center">
                <h3 class="title">@lang('ADDVERTISEMENT')</h3>
            </div>
            @php 
                echo advertisements("300x250")
            @endphp
        </div>
    </div>
</aside>