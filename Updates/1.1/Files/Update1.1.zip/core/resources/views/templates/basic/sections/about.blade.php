@php
   /*
    *   singleQuery True / false
    * By default singleQuery is false , If you want only one row you have to set `True`
    *
    * limit to fetch record of data
    */

    #getContent('data_key','singleQuery true/false','limit');
@endphp
